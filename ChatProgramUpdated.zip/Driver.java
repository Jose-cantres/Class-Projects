/*
 * Jose Cantres
 * Professor Fakhouri
 * CMP 420 Mon & Wed 11-2:40
 * 4/2/19
 */
public class Driver {

	public static void main(String[] arg) {
		StartGUI server = new StartGUI();
		do {
			ChatGUI.recieveData();
		} while (true);
	}
}
